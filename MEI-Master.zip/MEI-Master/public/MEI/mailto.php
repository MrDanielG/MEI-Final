<?php
    mail("ramiroestradag@gmail.com",$_POST["sub"],$_POST["msg"]);
?>
